# Aptean Hackathon Support AI

## Overview
The Aptean Hackathon Support AI project is designed to provide a multi-channel ingestion system for customer queries, utilizing a classification pipeline, a resolution engine, and a human escalation process. This project aims to streamline customer support by leveraging AI to handle queries efficiently while allowing for human intervention when necessary.

## Features
- **Multi-Channel Ingestion**: Supports queries from emails, chats, tweets, and voice transcripts.
- **Classification Pipeline**: Classifies queries based on priority, sentiment, intent, and compliance risk.
- **Resolution Engine**: Utilizes a Retrieval-Augmented Generation (RAG) model to generate responses based on ingested queries and a knowledge base.
- **Human Escalation Process**: Manages escalated cases for human review and intervention.
- **Feedback Mechanism**: Allows users to provide feedback on AI responses, which is logged for analysis.
- **Streamlit Application**: Provides a user-friendly interface with two tabs: Agent UI for query input and Supervisor Dashboard for analytics.

## Project Structure
```
aptean-hackathon-support-ai
├── src
│   ├── __init__.py
│   ├── ingestion
│   │   ├── __init__.py
│   │   ├── email_ingest.py
│   │   ├── chat_ingest.py
│   │   ├── tweet_ingest.py
│   │   └── voice_ingest.py
│   ├── classification
│   │   ├── __init__.py
│   │   └── classifier.py
│   ├── resolution
│   │   ├── __init__.py
│   │   └── rag_resolution_engine.py
│   ├── escalation
│   │   ├── __init__.py
│   │   └── escalation_queue.py
│   ├── db
│   │   ├── __init__.py
│   │   └── database.py
│   ├── feedback
│   │   ├── __init__.py
│   │   └── feedback.py
│   ├── app.py
│   └── utils.py
├── data
│   ├── emails.csv
│   ├── chats.json
│   ├── tweets.json
│   ├── voice.txt
│   └── kb.json
├── requirements.txt
└── README.md
```

## Setup Instructions
1. **Clone the Repository**: 
   ```
   git clone <repository-url>
   cd aptean-hackathon-support-ai
   ```

2. **Create a Virtual Environment**:
   ```
   python -m venv .venv
   source .venv/bin/activate  # On Windows use .venv\Scripts\activate
   ```

3. **Install Dependencies**:
   ```
   pip install -r requirements.txt
   ```

4. **Run the Application**:
   ```
   streamlit run src/app.py
   ```

## Usage
- **Agent UI**: Input customer queries and receive AI-generated responses or escalations.
- **Supervisor Dashboard**: View analytics, including ticket counts, sentiment distribution, and escalation logs.

## Acknowledgments
This project was developed as part of the Aptean Hackathon, showcasing the potential of AI in enhancing customer support systems.