from ingestion.email_ingest import load_emails
from ingestion.chat_ingest import load_chats
from ingestion.tweet_ingest import load_tweets
from ingestion.voice_ingest import load_voice
from classification.classifier import classify_ticket
from resolution.rag_resolution_engine import RAGResolver
from escalation.escalation_queue import EscalationQueue
from db.database import setup_db, audit_log
from feedback.feedback import record_feedback
import streamlit as st
import pandas as pd

COMPLIANCE_KEYWORDS = [
    "refund in cash", "guaranteed approval", "personal data", "ssn", "credit card", "cvv",
    "share your password", "bank account", "otp", "reset my password"
]


def run_streamlit_app():
    conn = setup_db()
    resolver = RAGResolver()

    st.set_page_config(page_title="Aptean Hackathon - Support AI", layout="wide")
    st.title("Aptean Hackathon - Support AI")

    tab1, tab2 = st.tabs(["Agent UI", "Supervisor Dashboard"])

    with tab1:
        st.header("Agent UI")
        channel = st.selectbox("Select Channel", ["Email", "Chat", "Twitter", "Voice"])
        user_input = st.text_area("Enter your query here:")
        if st.button("Submit"):
            if user_input:
                # Process the input based on the channel
                if channel == "Email":
                    _ = load_emails()
                elif channel == "Chat":
                    _ = load_chats()
                elif channel == "Twitter":
                    _ = load_tweets()
                elif channel == "Voice":
                    _ = load_voice()

                # Classification and resolution
                classification_result = classify_ticket(user_input, compliance_keywords=COMPLIANCE_KEYWORDS)
                resolution_result = resolver.resolve_ticket(user_input)

                st.subheader("Classification Result")
                st.json(classification_result)

                st.subheader("Resolution Result")
                st.json(resolution_result)

                # Prepare retrieved docs placeholder
                retrieved_docs = []

                # Write immutable audit log
                audit_id = audit_log(
                    conn,
                    channel=channel,
                    query=user_input,
                    response=resolution_result.get("response"),
                    escalate=bool(resolution_result.get("escalate", False)),
                    reason=resolution_result.get("reason"),
                    retrieved=retrieved_docs,
                    summary=resolution_result.get("summary"),
                    sentiment=classification_result.get("sentiment"),
                    response_time=0.0,
                )

                if resolution_result.get("escalate"):
                    escalation_queue = EscalationQueue(conn)
                    escalation_queue.add_escalation(
                        query=user_input,
                        retrieved=retrieved_docs,
                        summary=resolution_result.get("summary", ""),
                        sentiment=classification_result.get("sentiment"),
                    )

    with tab2:
        st.header("Supervisor Dashboard")
        df_audit = pd.read_sql_query("SELECT * FROM audit_logs ORDER BY id DESC", conn)
        if df_audit.empty:
            st.info("No tickets processed yet.")
        else:
            st.subheader("Audit Logs")
            st.dataframe(df_audit)


if __name__ == "__main__":
    run_streamlit_app()