from typing import Dict, Any

COMPLIANCE_KEYWORDS = [
    "refund in cash", "guaranteed approval", "personal data", "ssn", "credit card", "cvv",
    "share your password", "bank account", "otp", "reset my password"
]

def classify_priority(text: str) -> str:
    high_keywords = ["urgent", "asap", "immediately", "critical", "important"]
    return "High" if any(keyword in text.lower() for keyword in high_keywords) else "Normal"


def classify_sentiment(text: str, sentiment_pipeline) -> str:
    if sentiment_pipeline:
        try:
            result = sentiment_pipeline(text[:512])
            return result[0].get("label") if isinstance(result, list) and len(result) > 0 else None
        except Exception:
            return None
    return None


def classify_intent(text: str, intent_pipeline) -> str:
    candidate_labels = ["billing", "technical", "account", "sales", "refund", "other"]
    if intent_pipeline:
        try:
            result = intent_pipeline(text[:512], candidate_labels)
            return result.get("labels", [None])[0]
        except Exception:
            return None
    return None


def assess_compliance(text: str, compliance_keywords: list) -> Dict[str, Any]:
    flags = [kw for kw in (compliance_keywords or COMPLIANCE_KEYWORDS) if kw in text.lower()]
    return {"compliance_risk": len(flags) > 0, "comp_flags": flags}


def classify_ticket(text: str, sentiment_pipeline=None, intent_pipeline=None, compliance_keywords=None) -> Dict[str, Any]:
    priority = classify_priority(text)
    sentiment = classify_sentiment(text, sentiment_pipeline)
    intent = classify_intent(text, intent_pipeline)
    compliance = assess_compliance(text, compliance_keywords)

    return {
        "priority": priority,
        "sentiment": sentiment,
        "intent": intent,
        "compliance_risk": compliance["compliance_risk"],
        "comp_flags": compliance["comp_flags"],
    }