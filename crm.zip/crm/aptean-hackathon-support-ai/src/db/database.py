from __future__ import annotations

import os
import sqlite3
import time
import json
import hashlib
from typing import Any, List, Optional, Dict

# Database configuration
DB_PATH = os.path.join("data", "hackathon.db")

def setup_db(path: str = DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    cur = conn.cursor()
    
    # Create audit logs table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            channel TEXT,
            query TEXT,
            response TEXT,
            escalate INTEGER,
            reason TEXT,
            retrieved TEXT,
            summary TEXT,
            sentiment TEXT,
            response_time REAL
        )
        """
    )

    # Auto-migrate: ensure prev_hash and hash columns exist
    try:
        cur.execute("ALTER TABLE audit_logs ADD COLUMN prev_hash TEXT")
    except sqlite3.OperationalError:
        pass
    try:
        cur.execute("ALTER TABLE audit_logs ADD COLUMN hash TEXT")
    except sqlite3.OperationalError:
        pass
    
    # Create escalations table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS escalations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            query TEXT,
            retrieved TEXT,
            summary TEXT,
            sentiment TEXT,
            status TEXT
        )
        """
    )
    
    # Create feedback table
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            audit_id INTEGER,
            helpful INTEGER,
            comments TEXT,
            ts REAL
        )
        """
    )
    
    conn.commit()
    return conn

def get_last_hash(conn: sqlite3.Connection) -> Optional[str]:
    cur = conn.cursor()
    # Be resilient if column doesn't exist yet
    try:
        cur.execute("SELECT hash FROM audit_logs ORDER BY id DESC LIMIT 1")
        r = cur.fetchone()
        return r[0] if r and r[0] else None
    except sqlite3.OperationalError:
        return None

def audit_log(
    conn: sqlite3.Connection,
    channel: str,
    query: str,
    response: Optional[str],
    escalate: bool,
    reason: Optional[str],
    retrieved: List[Dict[str, Any]],
    summary: Optional[str],
    sentiment: Optional[str],
    response_time: float,
) -> int:
    prev = get_last_hash(conn) or ""
    payload = json.dumps(
        {
            "ts": time.time(),
            "channel": channel,
            "query": query,
            "response": response,
            "escalate": int(escalate),
            "reason": reason,
            "retrieved": retrieved,
            "summary": summary,
            "sentiment": sentiment,
            "response_time": response_time,
        },
        ensure_ascii=False,
    )
    new_hash = hashlib.sha256((prev + payload).encode("utf-8")).hexdigest()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO audit_logs (ts, channel, query, response, escalate, reason, retrieved, summary, sentiment, response_time, prev_hash, hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            time.time(),
            channel,
            query,
            response,
            int(escalate),
            reason,
            json.dumps(retrieved, ensure_ascii=False),
            summary,
            sentiment,
            response_time,
            prev,
            new_hash,
        ),
    )
    conn.commit()
    return cur.lastrowid

def enqueue_escalation(
    conn: sqlite3.Connection,
    query: str,
    retrieved: List[Dict[str, Any]],
    summary: str,
    sentiment: Optional[str],
):
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO escalations (ts, query, retrieved, summary, sentiment, status) VALUES (?, ?, ?, ?, ?, ?)",
        (time.time(), query, json.dumps(retrieved, ensure_ascii=False), summary, sentiment, "open"),
    )
    conn.commit()
    return cur.lastrowid

def record_feedback(conn: sqlite3.Connection, audit_id: int, helpful: bool, comments: Optional[str]):
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO feedback (audit_id, helpful, comments, ts) VALUES (?, ?, ?, ?)",
        (audit_id, int(helpful), comments, time.time()),
    )
    conn.commit()