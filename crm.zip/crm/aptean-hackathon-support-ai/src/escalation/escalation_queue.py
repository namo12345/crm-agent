from typing import List, Dict, Any
import sqlite3
import time
import json

class EscalationQueue:
    def __init__(self, db_connection: sqlite3.Connection):
        self.conn = db_connection

    def add_escalation(self, query: str, retrieved: List[Dict[str, Any]], summary: str, sentiment: str) -> int:
        cur = self.conn.cursor()
        cur.execute(
            "INSERT INTO escalations (ts, query, retrieved, summary, sentiment, status) VALUES (?, ?, ?, ?, ?, ?)",
            (time.time(), query, json.dumps(retrieved, ensure_ascii=False), summary, sentiment, "open")
        )
        self.conn.commit()
        return cur.lastrowid

    def get_escalation_queue(self) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM escalations ORDER BY id DESC")
        rows = cur.fetchall()
        return [
            {
                "id": row[0],
                "ts": row[1],
                "query": row[2],
                "retrieved": json.loads(row[3]),
                "summary": row[4],
                "sentiment": row[5],
                "status": row[6]
            }
            for row in rows
        ]

    def resolve_escalation(self, escalation_id: int, resolution: str):
        cur = self.conn.cursor()
        cur.execute("UPDATE escalations SET status = ? WHERE id = ?", ("resolved", escalation_id))
        self.conn.commit()
        
    