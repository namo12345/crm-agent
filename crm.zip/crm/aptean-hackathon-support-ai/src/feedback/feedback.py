from __future__ import annotations

import sqlite3
import time

# Database path
DB_PATH = "data/hackathon.db"

def record_feedback(audit_id: int, helpful: bool, comments: str = None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO feedback (audit_id, helpful, comments, ts) VALUES (?, ?, ?, ?)",
        (audit_id, int(helpful), comments, time.time())
    )
    conn.commit()
    conn.close()