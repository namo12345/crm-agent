from typing import List, Dict, Any
import json
import os

def ensure_data_dir():
    os.makedirs("data", exist_ok=True)

def load_chats(json_path: str = os.path.join("data", "chats.json")) -> List[Dict[str, Any]]:
    ensure_data_dir()
    if not os.path.exists(json_path):
        sample = [
            {"user": "alice", "message": "How do I reset my password?"},
            {"user": "bob", "message": "Is there a student discount?"}
        ]
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(sample, f, indent=2)
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [{"channel": "chat", "text": item.get("message", ""), "meta": item} for item in data]