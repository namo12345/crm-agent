from typing import List, Dict, Any
import pandas as pd
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), '../../data')
EMAILS_CSV = os.path.join(DATA_DIR, 'emails.csv')

def load_emails(csv_path: str = EMAILS_CSV) -> List[Dict[str, Any]]:
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"{csv_path} does not exist.")
    
    df = pd.read_csv(csv_path)
    emails = []
    for _, row in df.iterrows():
        emails.append({
            "channel": "email",
            "text": str(row.get("body", "")),
            "meta": {
                "from": row.get("from"),
                "subject": row.get("subject")
            }
        })
    return emails

def format_email_data(emails: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    formatted_data = []
    for email in emails:
        formatted_data.append({
            "channel": email["channel"],
            "text": email["text"],
            "meta": email["meta"]
        })
    return formatted_data

def ingest_emails() -> List[Dict[str, Any]]:
    emails = load_emails()
    return format_email_data(emails)