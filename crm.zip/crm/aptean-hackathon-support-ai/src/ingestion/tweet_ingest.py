import os
import json

def load_tweets(json_path="data/tweets.json"):
    if not os.path.exists(json_path):
        sample = [
            {"user": "@john", "text": "Why is my payment failing?"},
            {"user": "@mary", "text": "Love your app!"}
        ]
        os.makedirs(os.path.dirname(json_path), exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(sample, f, indent=2)
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [{"channel": "twitter", "text": item.get("text", ""), "meta": item} for item in data]