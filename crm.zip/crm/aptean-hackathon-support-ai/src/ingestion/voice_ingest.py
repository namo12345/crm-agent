import os

def load_voice(txt_path="data/voice.txt"):
    os.makedirs(os.path.dirname(txt_path), exist_ok=True)
    if not os.path.exists(txt_path):
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("My order has not arrived yet.\nHow do I reset my password?\n")
    with open(txt_path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    return [{"channel": "voice", "text": ln, "meta": {}} for ln in lines]