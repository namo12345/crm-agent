from typing import Any, Dict, List
import json
import random

class RAGResolver:
    def __init__(self, kb_path: str = "data/kb.json"):
        self.kb = self.load_knowledge_base(kb_path)
        self.stopwords = set(
            [
                "the","is","at","which","on","for","a","an","and","or","to","of","in","do","you","i","we","your","how","what","my","our","it",
            ]
        )

    def load_knowledge_base(self, kb_path: str) -> List[Dict[str, Any]]:
        with open(kb_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def resolve_ticket(self, query: str) -> Dict[str, Any]:
        response, retrieved = self.search_kb(query)
        escalate = len(retrieved) == 0
        return {
            "response": response,
            "escalate": escalate,
            "reason": "Escalation needed" if escalate else None,
            "summary": self.generate_summary(response),
            "retrieved": retrieved,
        }

    def _tokens(self, text: str) -> List[str]:
        return [t for t in text.lower().split() if len(t) >= 3 and t not in self.stopwords]

    def search_kb(self, query: str) -> (str, List[Dict[str, Any]]):
        q = query.lower()
        # Direct substring match
        for item in self.kb:
            if q in item["question"].lower():
                return item["answer"], [item]

        # Simple synonym/keyword mapping for common intents
        synonyms = {
            "student discount": [
                "student discount",
                "student pricing",
                "student offer",
                "student plan",
                "student rate",
                "discount for students",
            ],
            "refund": ["refund", "money back"],
            "password": ["password", "reset password", "forgot password"],
            "billing": ["billing", "invoice", "payment"],
            "free trial": ["free trial", "trial", "try for free"],
        }
        if any(any(k in q for k in keys) for keys in synonyms.values()):
            # choose best KB entry by token overlap
            q_tokens = set(self._tokens(q))
            best = None
            best_score = 0
            for item in self.kb:
                question_tokens = set(self._tokens(item["question"]))
                score = len(q_tokens & question_tokens)
                if score > best_score:
                    best = item
                    best_score = score
            if best and best_score >= 2:
                return best["answer"], [best]

        # Token overlap fallback with threshold
        q_tokens = set(self._tokens(q))
        best = None
        best_score = 0
        for item in self.kb:
            question_tokens = set(self._tokens(item["question"]))
            score = len(q_tokens & question_tokens)
            if score > best_score:
                best = item
                best_score = score
        # Require minimum confidence
        if best and best_score >= 2:
            return best["answer"], [best]

        return "I'm sorry, I couldn't find an answer to your question.", []

    def should_escalate(self, response: str) -> bool:
        # Escalate if no actionable answer
        return response.startswith("I'm sorry, I couldn't find")

    def generate_summary(self, response: str) -> str:
        return f"Response generated: {response[:50]}..."  # Short summary of the response