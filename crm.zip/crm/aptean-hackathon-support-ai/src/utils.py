def format_query_data(query: str) -> dict:
    return {
        "text": query,
        "meta": {
            "timestamp": datetime.now().isoformat(),
        }
    }

def log_message(message: str, level: str = "INFO") -> None:
    timestamp = datetime.now().isoformat()
    print(f"{timestamp} - {level}: {message}")

def validate_query(query: str) -> bool:
    return bool(query.strip())

def extract_channel_info(channel_data: dict) -> str:
    return channel_data.get("channel", "unknown")

def prepare_feedback_data(audit_id: int, helpful: bool, comments: str) -> dict:
    return {
        "audit_id": audit_id,
        "helpful": helpful,
        "comments": comments,
        "timestamp": datetime.now().isoformat(),
    }