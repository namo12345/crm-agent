from audit_log import log_event, verify_logs

def ai_core(query):
    """Dummy AI that classifies and resolves"""
    if "password" in query.lower():
        category = "Account Issue"
        resolution = "Password reset link sent"
    elif "billing" in query.lower():
        category = "Billing"
        resolution = "Billing details updated"
    else:
        category = "General"
        resolution = "Forwarded to human agent"

    # Log the interaction
    log_event(query, category, resolution, model_version="v1.0", confidence=0.9)

    return resolution
 
if __name__ == "__main__":
    print(ai_core("I forgot my password"))
    print(ai_core("How to update billing?"))

    print("Ledger valid?", verify_logs())