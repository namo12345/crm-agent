import hashlib, json, os, time, uuid

LOG_FILE = "audit_log.json"

# Initialize log file if not present
if not os.path.exists(LOG_FILE):
    with open(LOG_FILE, "w") as f:
        json.dump([], f)

def get_last_hash():
    """Get the hash of the last log entry"""
    with open(LOG_FILE, "r") as f:
        logs = json.load(f)
        return logs[-1]["hash"] if logs else "0" * 64

def calculate_hash(entry):
    """Calculate SHA256 hash of entry"""
    entry_copy = entry.copy()
    entry_copy.pop("hash", None)
    return hashlib.sha256(json.dumps(entry_copy, sort_keys=True).encode()).hexdigest()

def log_event(query, category, resolution, model_version="v1.0", confidence=0.0):
    """Add a new event to the audit log"""
    entry = {
        "id": str(uuid.uuid4()),
        "query": query,
        "category": category,
        "resolution": resolution,
        "confidence": confidence,
        "model_version": model_version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "prev_hash": get_last_hash()
    }
    entry["hash"] = calculate_hash(entry)

    with open(LOG_FILE, "r+") as f:
        logs = json.load(f)
        logs.append(entry)
        f.seek(0)
        json.dump(logs, f, indent=4)

def verify_logs():
    """Verify the integrity of all logs"""
    with open(LOG_FILE, "r") as f:
        logs = json.load(f)

    prev_hash = "0" * 64
    for entry in logs:
        if entry["prev_hash"] != prev_hash:
            return False
        if calculate_hash(entry) != entry["hash"]:
            return False
        prev_hash = entry["hash"]
    return True