import sqlite3
import datetime

DB = "feedback_loop.db"

def analyze():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    
    # Total tickets
    c.execute("SELECT COUNT(*) FROM tickets")
    total_tickets = c.fetchone()[0]
    
    # SLA compliance
    c.execute("SELECT created_at, resolved_at, sla_seconds FROM tickets")
    sla_met = 0
    for created, resolved, sla_seconds in c.fetchall():
        if resolved:
            created_dt = datetime.datetime.fromisoformat(created)
            resolved_dt = datetime.datetime.fromisoformat(resolved)
            if (resolved_dt - created_dt).total_seconds() <= sla_seconds:
                sla_met += 1
    sla_compliance = round((sla_met / total_tickets) * 100, 2) if total_tickets else 0
    
    # Ratings
    c.execute("SELECT rating, COUNT(*) FROM feedback GROUP BY rating")
    ratings = dict(c.fetchall())
    
    # Corrections
    c.execute("SELECT COUNT(*) FROM feedback WHERE correction != ''")
    corrections = c.fetchone()[0]
    
    conn.close()
    
    print("SLA Compliance:", sla_compliance, "%")
    print("Ratings:", ratings)
    print("Total Corrections Submitted:", corrections)

if __name__ == "__main__":
    analyze()
