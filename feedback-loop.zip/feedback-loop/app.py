from flask import Flask, request, redirect, render_template
import sqlite3
import datetime
import os

# -------------------------------
# CONFIG
# -------------------------------
DB_PATH = os.path.join(os.path.dirname(__file__), "feedback_loop.db")
app = Flask(__name__)

# -------------------------------
# DATABASE FUNCTIONS
# -------------------------------

def create_tables():
    """Create tickets and feedback tables if they don't exist."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT,
            query TEXT,
            ai_answer TEXT,
            created_at DATETIME,
            resolved_at DATETIME,
            sla_seconds INTEGER
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER,
            rating TEXT,
            correction TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(ticket_id) REFERENCES tickets(id)
        )
    """)
    
    conn.commit()
    conn.close()

def add_ticket(customer_name, query, ai_answer, sla_seconds=3600):
    """Add a new ticket to the database."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    now = datetime.datetime.now()
    c.execute("""
        INSERT INTO tickets (customer_name, query, ai_answer, created_at, sla_seconds)
        VALUES (?, ?, ?, ?, ?)
    """, (customer_name, query, ai_answer, now, sla_seconds))
    
    ticket_id = c.lastrowid
    conn.commit()
    conn.close()
    return ticket_id

def save_feedback(ticket_id, rating, correction):
    """Insert a feedback record into the database."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO feedback (ticket_id, rating, correction)
        VALUES (?, ?, ?)
    """, (ticket_id, rating, correction))
    
    # Update resolved_at timestamp
    c.execute("""
        UPDATE tickets
        SET resolved_at = ?
        WHERE id = ?
    """, (datetime.datetime.now(), ticket_id))
    
    conn.commit()
    conn.close()

def get_bad_feedback():
    """Return all tickets with bad feedback and corrections."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT t.query, f.correction
        FROM tickets t
        JOIN feedback f ON t.id = f.ticket_id
        WHERE f.rating = 'bad'
    """)
    
    data = c.fetchall()
    conn.close()
    return data

# -------------------------------
# FLASK ROUTES
# -------------------------------

@app.route("/")
def home():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM tickets ORDER BY created_at DESC")
    tickets = c.fetchall()
    conn.close()
    return render_template("home.html", tickets=tickets)

@app.route("/ticket/<int:ticket_id>")
def ticket_page(ticket_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,))
    ticket = c.fetchone()
    conn.close()
    
    if ticket:
        return render_template("ticket.html", ticket=ticket)
    else:
        return "Ticket not found", 404

@app.route("/submit_feedback", methods=["POST"])
def submit_feedback_route():
    ticket_id = request.form["ticket_id"]
    rating = request.form["rating"]
    correction = request.form.get("correction", "")
    
    save_feedback(ticket_id, rating, correction)
    
    return redirect(f"/ticket/{ticket_id}")

@app.route("/feedback_summary")
def feedback_summary():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Count ratings
    c.execute("SELECT rating, COUNT(*) FROM feedback GROUP BY rating")
    rating_counts = c.fetchall()
    
    # Count corrections
    c.execute("SELECT COUNT(*) FROM feedback WHERE correction != ''")
    corrections_count = c.fetchone()[0]
    
    conn.close()
    return render_template("feedback_summary.html", ratings=rating_counts, corrections=corrections_count)

@app.route("/dashboard")
def dashboard():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Total tickets
    c.execute("SELECT COUNT(*) FROM tickets")
    total_tickets = c.fetchone()[0]
    
    # Ratings count
    c.execute("SELECT rating, COUNT(*) FROM feedback GROUP BY rating")
    rating_counts = dict(c.fetchall())
    
    good_count = rating_counts.get('good', 0)
    bad_count = rating_counts.get('bad', 0)
    accuracy = (good_count / total_tickets * 100) if total_tickets else 0
    
    # Corrections
    c.execute("SELECT COUNT(*) FROM feedback WHERE correction != ''")
    total_corrections = c.fetchone()[0]
    
    # SLA compliance
    c.execute("""
        SELECT COUNT(*) FROM tickets
        WHERE resolved_at IS NOT NULL AND (strftime('%s', resolved_at) - strftime('%s', created_at)) <= sla_seconds
    """)
    sla_met = c.fetchone()[0]
    
    sla_compliance = round((sla_met / total_tickets) * 100, 2) if total_tickets else 0
    sla_violations = total_tickets - sla_met
    
    conn.close()
    
    stats = {
        "total_tickets": total_tickets,
        "good": good_count,
        "bad": bad_count,
        "accuracy": round(accuracy, 2),
        "corrections": total_corrections,
        "sla_compliance": sla_compliance,
        "sla_violations": sla_violations
    }
    
    return render_template("dashboard.html", stats=stats)

# -------------------------------
# MAIN
# -------------------------------

if __name__ == "__main__":
    # Ensure tables exist
    create_tables()
    
    # Add sample tickets if none exist
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM tickets")
    count = c.fetchone()[0]
    conn.close()
    
    if count == 0:
        add_ticket("John Doe", "How do I reset my password?", "Your password has been reset.")
        add_ticket("Alice Smith", "How can I change my email?", "You can update your email in account settings.")
        add_ticket("Bob Lee", "Why is my order delayed?", "Your order will arrive in 3-5 days.")
        add_ticket("Carol Tan", "How do I delete my account?", "You can request account deletion in settings.")
        add_ticket("David Kim", "How do I update my billing info?", "Go to billing section to update info.")
        print("Sample tickets added.")
    
    app.run(debug=True)
