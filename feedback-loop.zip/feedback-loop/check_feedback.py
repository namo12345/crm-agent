import sqlite3
import os

# Path to your database (make sure it matches your Flask app)
DB_PATH = os.path.join(os.path.dirname(__file__), "feedback_loop.db")

def main():
    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Check which tables exist
    c.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = c.fetchall()
    print("Tables in DB:", tables)

    # Fetch first 20 feedback entries
    c.execute("SELECT id, ticket_id, rating, correction, timestamp FROM feedback ORDER BY id DESC LIMIT 20;")
    rows = c.fetchall()

    if not rows:
        print("No feedback found.")
    else:
        print("\nRecent Feedback Submissions:\n")
        for row in rows:
            print(f"Feedback ID: {row[0]}")
            print(f"Ticket ID:   {row[1]}")
            print(f"Rating:      {row[2]}")
            print(f"Correction:  {row[3]}")
            print(f"Timestamp:   {row[4]}")
            print("-" * 40)

    conn.close()

if __name__ == "__main__":
    main()
