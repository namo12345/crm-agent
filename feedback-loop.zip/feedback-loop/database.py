import sqlite3

def create_connection():
    conn = sqlite3.connect("feedback_loop.db")  # database file
    return conn

def create_tables():
    conn = create_connection()
    c = conn.cursor()
    
    # Table for tickets
    c.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT,
            query TEXT,
            ai_answer TEXT
        )
    """)
    
    # Table for feedback
    c.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER,
            rating TEXT,
            correction TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(ticket_id) REFERENCES tickets(id)
        )
    """)
    
    conn.commit()
    conn.close()

# Run this once to create the tables
if __name__ == "__main__":
    create_tables()
    print("Tables created successfully!")
