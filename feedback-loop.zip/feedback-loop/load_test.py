import sqlite3
import random
import time

DB = "db/feedback.db"

def create_table():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_rating INTEGER,
            response_time REAL,
            resolution_time REAL,
            sla_met BOOLEAN,
            comment TEXT
        )
    """)
    conn.commit()
    conn.close()

def insert_dummy_data(n=20):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    
    for _ in range(n):
        rating = random.randint(1, 5)
        response_time = round(random.uniform(1, 10), 2)   # 1s to 10s
        resolution_time = round(random.uniform(0.5, 8), 2) # 0.5h to 8h
        sla_met = response_time <= 3 and resolution_time <= 4
        comment = "Test data"
        
        c.execute(
            "INSERT INTO feedback (user_rating, response_time, resolution_time, sla_met, comment) VALUES (?, ?, ?, ?, ?)",
            (rating, response_time, resolution_time, sla_met, comment)
        )
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_table()
    insert_dummy_data()
    print("✅ Dummy feedback data inserted into database!")
