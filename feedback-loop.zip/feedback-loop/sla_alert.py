import sqlite3
import datetime
import os

# Path to your database
DB_PATH = os.path.join(os.path.dirname(__file__), "feedback_loop.db")

def check_sla_violations():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Get all unresolved tickets
    c.execute("""
        SELECT id, customer_name, created_at, sla_seconds
        FROM tickets
        WHERE resolved_at IS NULL
    """)
    tickets = c.fetchall()

    violations = []

    for ticket_id, customer_name, created_at, sla_seconds in tickets:
        # Convert string to datetime if needed
        if isinstance(created_at, str):
            created_at = datetime.datetime.fromisoformat(created_at)

        elapsed = (datetime.datetime.now() - created_at).total_seconds()

        if elapsed > sla_seconds:
            violations.append((ticket_id, customer_name, elapsed))

    conn.close()

    if violations:
        print("⚠️ SLA Violations Detected:")
        for ticket_id, customer_name, elapsed in violations:
            print(f"- Ticket #{ticket_id} ({customer_name}) exceeded SLA by {int(elapsed - sla_seconds)} seconds")
    else:
        print("✅ No SLA violations detected.")

if __name__ == "__main__":
    check_sla_violations()
