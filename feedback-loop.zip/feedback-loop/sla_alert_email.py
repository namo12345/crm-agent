import sqlite3
import datetime
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# -------------------------------
# CONFIG
# -------------------------------
DB_PATH = os.path.join(os.path.dirname(__file__), "feedback_loop.db")

# Email settings
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_USER = "apteantickets@gmail.com"
EMAIL_PASSWORD = "aptean123"  # Use App Password if 2FA is enabled
TO_EMAIL = "khiraam@gmail.com"

# -------------------------------
# FUNCTIONS
# -------------------------------

def check_sla_violations():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Get all unresolved tickets
    c.execute("""
        SELECT id, customer_name, created_at, sla_seconds
        FROM tickets
        WHERE resolved_at IS NULL
    """)
    tickets = c.fetchall()
    conn.close()

    violations = []

    for ticket_id, customer_name, created_at, sla_seconds in tickets:
        # Convert string to datetime if needed
        if isinstance(created_at, str):
            created_at = datetime.datetime.fromisoformat(created_at)

        elapsed = (datetime.datetime.now() - created_at).total_seconds()

        if elapsed > sla_seconds:
            violations.append((ticket_id, customer_name, int(elapsed - sla_seconds)))

    return violations

def send_email(violations):
    if not violations:
        return

    # Create email content
    subject = "⚠️ SLA Violations Alert"
    body = "The following tickets have exceeded their SLA:\n\n"
    for ticket_id, customer_name, over_seconds in violations:
        body += f"- Ticket #{ticket_id} ({customer_name}) exceeded SLA by {over_seconds} seconds\n"

    msg = MIMEMultipart()
    msg["From"] = EMAIL_USER
    msg["To"] = TO_EMAIL
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    # Send email
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASSWORD)
        server.send_message(msg)
        server.quit()
        print("📧 SLA violation email sent successfully.")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# -------------------------------
# MAIN
# -------------------------------

if __name__ == "__main__":
    violations = check_sla_violations()
    if violations:
        print("⚠️ SLA Violations Detected:")
        for ticket_id, customer_name, over_seconds in violations:
            print(f"- Ticket #{ticket_id} ({customer_name}) exceeded SLA by {over_seconds} seconds")
        send_email(violations)
    else:
        print("✅ No SLA violations detected.")
